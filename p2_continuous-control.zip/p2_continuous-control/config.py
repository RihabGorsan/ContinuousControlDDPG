import argparse 
import torch 

class Config:
    DEVICE = torch.device('cpu')
    
    def __init__(self):
        self.parser= argparse.ArgumentParser()
        self.discount = 0.99
        self.actor_layers = None
        self.critic_layers = None 
        self.rollout_lenght = None
        self.gradient_clip = None 
        self.use_gae = False 
        self.num_workers = None
        self.tau = 0.001
        self.batch_size = 128
        self.buffer_size = 100000