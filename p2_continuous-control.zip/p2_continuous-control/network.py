import torch
import numpy as np 

from torch import nn 
import torch.nn.functional as F 

class Network(nn.Module) :
    
    def __init__(self, input_size, output_size, hidden_layers, model_type ) :
        super().__init__()

        self.hidden_layers = nn.ModuleList([nn.Linear(input_size,hidden_layers[0])])
        self.name = model_type
        if model_type == 'actor' :

            self.mu_hidden_layers = nn.ModuleList([nn.Linear(input_size,hidden_layers[0])])
            self.sigma_hidden_layers = nn.ModuleList([nn.Linear(input_size,hidden_layers[0])])

            self.layer_size = zip(hidden_layers[:-1], hidden_layers[1:])
            self.mu_hidden_layers.extend([nn.Linear(h1,h2) for h1, h2 in self.layer_size])
            self.sigma_hidden_layers.extend([nn.Linear(h1,h2) for h1, h2 in self.layer_size])

            self.mu_output = nn.Linear(hidden_layers[-1],output_size)
            self.sigma_output = nn.Linear(hidden_layers[-1],output_size)

        elif model_type == 'critic' :
            self.hidden_layers = nn.ModuleList([nn.Linear(input_size,hidden_layers[0])])
            self.layer_size = zip(hidden_layers[:-1], hidden_layers[1:])
            self.hidden_layers.extend([nn.Linear(h1,h2) for h1, h2 in self.layer_size])
            self.output = nn.Linear(hidden_layers[-1],output_size)



    def forward(self, x) :
        if self.name == 'critic'  :
            x = torch.from_numpy(x).float() 
            
            for linear in self.hidden_layers :
                x = F.relu(linear(x))
            
            
                return self.output(x)
        
        elif self.name == 'actor' :
            h = np.copy(x)
            h = torch.from_numpy(h).float()
            x = torch.from_numpy(x).float()

            for linear in self.mu_hidden_layers :
                h = F.relu(linear(h))
            
            for linear in self.sigma_hidden_layers :
                x = F.relu(linear(x))
            
            mu = self.mu_output(h)
            sigma = F.softplus(self.sigma_output(x)) 

           
            self.policy = torch.distributions.Normal(mu, sigma)

            return torch.clamp(self.policy.sample_n(1), -1,1)



        


        
        

    
    
