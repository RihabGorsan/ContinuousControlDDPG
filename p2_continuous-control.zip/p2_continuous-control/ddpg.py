
import torch 
import numpy as np 
import torch.nn.functional as F 
import torch.optim as optim
import random 
from copy import deepcopy
from torch import nn 
from config import Config
from collections import namedtuple, deque 

class Network(nn.Module):

    def __init__(self, state_size, action_size, layer_size, model_type):

        super().__init__()
        self.model_type = model_type
        if model_type == 'actor' : 
            
            self.hidden_layers = nn.ModuleList([nn.Linear(state_size, layer_size[0])])
            self.layer_sizes = zip(layer_size[:-1],layer_size[1:])
            self.hidden_layers.extend([nn.Linear(i,j) for i,j in self.layer_sizes])
            self.output = nn.Linear(layer_size[-1],action_size)

        elif model_type == 'critic':
            
            self.hidden_layers = nn.ModuleList([nn.Linear(state_size, layer_size[0]-action_size)])
            self.layer_sizes = zip(layer_size[:-1],layer_size[1:])
            self.hidden_layers.extend([nn.Linear(i,j) for i,j in self.layer_sizes])
            self.output = nn.Linear(layer_size[-1],1)

    def forward(self, states, actions = None) :
        
        x = torch.Tensor(states).float() 
        if self.model_type == 'actor' :
            for linear in self.hidden_layers :
                x = F.relu(linear(x))
            return F.tanh(self.output(x))

        elif self.model_type == 'critic' :
            a = torch.Tensor(actions).float()  
            linear = self.hidden_layers[0] 
            x = F.relu(linear(x))
            xs = torch.cat((x,a),1)

            for linear in self.hidden_layers[1:] :
                xs = F.relu(linear(xs))

            return self.output(xs)




class ReplayBuffer:

    def __init__(self, action_size, buffer_size, batch_size):

        self.action_size = action_size
        self.memory = deque(maxlen=buffer_size)  
        self.batch_size = batch_size
        self.experience = namedtuple("Experience", field_names=["state", "action", "reward", "next_state", "done"])
        

    def add(self, state, action, reward, next_state, done) :
        
        e = self.experience(state, action, reward, next_state, done)

        self.memory.append(e)
    
    def sample(self):

        experiences = random.sample(self.memory, k= self.batch_size)

        states = torch.Tensor(np.vstack([e.state for e in experiences if e is not None])).float()
        actions = torch.Tensor(np.vstack([e.action for e in experiences if e is not None])).float()
        rewards = torch.Tensor(np.vstack([e.reward for e in experiences if e is not None])).float()
        next_states = torch.Tensor(np.vstack([e.next_state for e in experiences if e is not None])).float()
        dones = torch.Tensor(np.vstack([e.done for e in experiences if e is not None]).astype(np.uint8)).float()

        return (states, actions, rewards, next_states, dones)
    
    def __len__(self):
        return len(self.memory)

class RandomProcess(object):
    def reset_states(self):
        pass

class OrnsteinUhlenbeckProcess(RandomProcess):
    def __init__(self, size, std, theta=.15, dt=1e-2, x0=None):
        self.theta = theta
        self.mu = 0
        self.std = std
        self.dt = dt
        self.x0 = x0
        self.size = size
        self.reset_states()

    def sample(self):
        x = self.x_prev + self.theta * (self.mu - self.x_prev) * self.dt + self.std * np.sqrt(self.dt) * np.random.randn(self.size)
        self.x_prev = x
        return x

    def reset_states(self):
        self.x_prev = self.x0 if self.x0 is not None else np.zeros(self.size)

class Agent:

    def __init__(self,config, state_size, action_size):
        self.config = config
        self.action_size = action_size
        self.state_size = state_size 
        self.critic = Network(state_size, action_size, config.critic_layers, 'critic')
        self.actor = Network(state_size, action_size, config.actor_layers, 'actor')
        self.target_critic =  Network(state_size, action_size, config.critic_layers, 'critic')
        self.target_critic.load_state_dict(self.critic.state_dict())
        self.target_actor = Network(state_size, action_size, config.actor_layers, 'actor')
        self.target_actor.load_state_dict(self.actor.state_dict())
        self.memory = ReplayBuffer(action_size, config.buffer_size, config.batch_size)
        self.critic_optimizer = optim.Adam(self.critic.parameters())
        self.actor_optimizer = optim.Adam(self.actor.parameters())
        self.randomProcess = OrnsteinUhlenbeckProcess(action_size, 0.2)
    
    def act(self, x, add_noise = True) : 
        
        self.actor.eval()
        action = self.actor.forward(x).detach().numpy() + self.randomProcess.sample()
        self.actor.train()
        
        return np.clip(action, -1, 1) 
    
    def reset(self) :
        self.randomProcess.reset_states()

    
    def step(self, state, action, reward, next_state, done):
        
        self.store(state, action, reward, next_state, done)
        if self.memory.__len__() > self.config.batch_size:
            for _ in range(3) :
                self.learn()


    def store(self, state, action, reward, next_state, done) :
        
        self.memory.add(state, action, reward, next_state, done)

    
    def sample(self) :
    
        return self.memory.sample()

    
    def soft_update(self, target_model, local_model):
        tau = self.config.tau 
        for target_param, local_param in zip(target_model.parameters(), local_model.parameters()) :
            target_param = tau * target_param + (1 - tau) * local_param

    
    def learn(self):
        
        states, actions, rewards, next_states, dones = self.sample()
        target_action = self.target_actor.forward(next_states)
        target_Qvalues = self.target_critic.forward(next_states, target_action)
        td_estimate = rewards + self.config.discount * target_Qvalues * (1 - dones)
        current_Qvalues = self.critic.forward(states, actions) 
        value_loss = (td_estimate - current_Qvalues).pow(2).mean()
        actions_pred = self.actor.forward(states)
        policy_loss =  - self.critic.forward(states, actions_pred).mean()

        self.critic_optimizer.zero_grad()
        value_loss.backward()
        torch.nn.utils.clip_grad_norm_(self.critic.parameters(), 1)
        self.critic_optimizer.step()
        
        self.actor_optimizer.zero_grad()
        policy_loss.backward()
        torch.nn.utils.clip_grad_norm_(self.actor.parameters(), 1)
        self.actor_optimizer.step()

        self.soft_update(self.target_actor, self.actor)
        self.soft_update(self.target_critic, self.critic)

    
            




        



