import torch
import numpy as np 

from network import Network
from torch import nn 
import torch.optim as optim 
import torch.nn.functional as F 

device = torch.device( "cpu")

class agent:

    def __init__(self, config, state_size, action_size) :

        self.config = config
        self.actor = Network(state_size, action_size, config.actor_layers, 'actor').to(device)
        self.critic = Network(state_size, 1, config.critic_layers,'critic').to(device)
        self.optimizer = optim.Adam([{'params':self.actor.parameters()},{'params':self.critic.parameters()}], lr = 1e-5)

    def sample_action(self, state) :
        
        return self.actor.forward(state)

    def sample_value(self, state): 
        
        return self.critic.forward(state)


    def step(self, sarsa) :
        
        state, action, reward, next_state, done = sarsa
        
        if not done :
            v = self.sample_value(state)
            
            next_value = self.sample_value(next_state) 
            td_error = reward + self.config.discount * next_value - v

            value_loss = 0.5 * td_error.pow(2).mean()
            
            policy_loss = -(td_error * self.actor.policy.log_prob(action)).mean()

            self.optimizer.zero_grad()
            loss = policy_loss + value_loss
            
            loss.backward()
            
            self.optimizer.step()



        

        
         